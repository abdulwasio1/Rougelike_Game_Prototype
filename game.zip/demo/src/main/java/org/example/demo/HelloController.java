package org.example.demo;

import javafx.fxml.FXML;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Label;
import javafx.scene.effect.Light;
import javafx.scene.image.Image;
import javafx.scene.input.KeyCode;

import java.util.ArrayList;
import java.util.Iterator;

public class HelloController {
    
    private static final int WIDTH = 600;
    private static final int HEIGHT = WIDTH;
    private static final int ROWS = 10;
    private static final int COLUMNS = ROWS;
    private static final int SQUARE_SIZE = WIDTH / COLUMNS;

    private static final int RIGHT = 0;
    private static final int LEFT = 1;
    private static final int UP = 2;
    private static final int DOWN = 3;
    @FXML
    private Canvas canvas;

    private GraphicsContext gc;
    private Light.Point playerPosition;
    private Image playerImage;
    private Image backgroundImage;
    private final ArrayList<GameItem> items = new ArrayList<>();
    private int health = 100;
    private int energy = 100;
    private int coins = 0;

    private int currentDirection = -1;

    @FXML
    private Label healthLabel;

    @FXML
    private Label energyLabel;

    @FXML
    private Label coinsLabel;

    @FXML
    public void initialize() {

        gc = canvas.getGraphicsContext2D();

        backgroundImage = new Image(
                getClass().getResourceAsStream(
                        "/org/example/demo/img/background.jpg"
                )
        );

        playerImage = new Image(
                getClass().getResourceAsStream(
                        "/org/example/demo/img/character.png"
                )
        );

        playerPosition = new Light.Point();

        for (ItemType type : ItemType.values()) {

            int randomNum = (int) (Math.random() * 4) + 1;

            for (int i = 0; i < randomNum; i++) {
                items.add(generateItem(type));
            }
        }

        updateHUD();

        run(gc);
    }

    public void setupInput(Scene scene) {

        scene.setOnKeyPressed(event -> {

            KeyCode code = event.getCode();

            if (code == KeyCode.RIGHT) {
                currentDirection = RIGHT;

            } else if (code == KeyCode.LEFT) {
                currentDirection = LEFT;

            } else if (code == KeyCode.UP) {
                currentDirection = UP;

            } else if (code == KeyCode.DOWN) {
                currentDirection = DOWN;
            }

            run(gc);
        });
    }


    public void run(GraphicsContext gc) {

        switch (currentDirection) {

            case UP -> moveUp();

            case DOWN -> moveDown();

            case LEFT -> moveLeft();

            case RIGHT -> moveRight();
        }
        checkItemsCollected();

        drawBackground(gc);
        drawItems(gc);
        drawPlayer(gc);
    }

    public void drawBackground(GraphicsContext gc) {

        gc.drawImage(
                backgroundImage,
                0,
                0,
                WIDTH,
                HEIGHT
        );
    }

    public GameItem generateItem(ItemType type) {

        int x;
        int y;
        boolean occupied;

        Image image;

        switch (type) {

            case COIN:
                image = new Image(
                        getClass().getResourceAsStream(
                                "/org/example/demo/img/coin.png"
                        )
                );
                break;

            case HEALTH:
                image = new Image(
                        getClass().getResourceAsStream(
                                "/org/example/demo/img/heart.png"
                        )
                );
                break;

            case ENERGY:
                image = new Image(
                        getClass().getResourceAsStream(
                                "/org/example/demo/img/energy.png"
                        )
                );
                break;

            case DAMAGE:
                image = new Image(
                        getClass().getResourceAsStream(
                                "/org/example/demo/img/damage.png"
                        )
                );
                break;

            default:
                throw new IllegalArgumentException("Unknown item type");
        }

        do {

            x = (int) (Math.random() * COLUMNS) * SQUARE_SIZE;
            y = (int) (Math.random() * ROWS) * SQUARE_SIZE;

            occupied = false;

            for (GameItem item : items) {

                if (item.x == x && item.y == y) {
                    occupied = true;
                    break;
                }
            }

        } while (occupied);

        return new GameItem(type, x, y, image);
    }


    public void drawPlayer(GraphicsContext gc) {

        gc.drawImage(
                playerImage,
                playerPosition.getX() * SQUARE_SIZE,
                playerPosition.getY() * SQUARE_SIZE,
                SQUARE_SIZE,
                SQUARE_SIZE
        );
    }


    // Move player right
    void moveRight() {

        playerImage = new Image(
                getClass().getResourceAsStream(
                        "/org/example/demo/img/character_right.png"
                )
        );

        playerPosition.setX(playerPosition.getX() + 1);
    }


    // Move player left
    void moveLeft() {

        playerImage = new Image(
                getClass().getResourceAsStream(
                        "/org/example/demo/img/character_left.png"
                )
        );

        playerPosition.setX(playerPosition.getX() - 1);
    }


    void moveUp() {

        playerImage = new Image(
                getClass().getResourceAsStream(
                        "/org/example/demo/img/character_up.png"
                )
        );

        playerPosition.setY(playerPosition.getY() - 1);
    }


    void moveDown() {

        playerImage = new Image(
                getClass().getResourceAsStream(
                        "/org/example/demo/img/character.png"
                )
        );

        playerPosition.setY(playerPosition.getY() + 1);
    }

    void drawItems(GraphicsContext gc) {

        for (GameItem item : items) {

            gc.drawImage(
                    item.img,
                    item.x,
                    item.y,
                    SQUARE_SIZE,
                    SQUARE_SIZE
            );
        }
    }

    private void collectItem(GameItem item) {

        switch (item.type) {

            case COIN:
                coins++;
                break;

            case HEALTH:
                health = Math.min(100, health + 20);
                break;

            case ENERGY:
                energy = Math.min(100, energy + 15);
                break;

            case DAMAGE:
                health = health - 20;
                break;
        }

        updateHUD();
    }


    private void updateHUD() {

        healthLabel.setText("Health: " + health);
        energyLabel.setText("Energy: " + energy);
        coinsLabel.setText("Coins: " + coins);
    }

    private void checkItemsCollected() {

        Iterator<GameItem> iterator = items.iterator();

        while (iterator.hasNext()) {

            GameItem item = iterator.next();

            double playerX = playerPosition.getX() * SQUARE_SIZE;
            double playerY = playerPosition.getY() * SQUARE_SIZE;

            if (playerX == item.x && playerY == item.y) {

                collectItem(item);
                iterator.remove();
            }
        }
    }
}
